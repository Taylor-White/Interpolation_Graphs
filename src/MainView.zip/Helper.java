import java.util.ArrayList;


public class Helper {
    
	public static double xMin(ArrayList<Coordinates> coordinates, int counter){
        if(counter == 0)
           return -100;
        double min = coordinates.get(0).getX();
        for(int i=0; i<coordinates.size()-1; ++i){
           if (coordinates.get(i+1).getX() < coordinates.get(i).getX())
              min = coordinates.get(i+1).getX();
        }
        return min;
     } 
    public static double xMax(ArrayList<Coordinates> coordinates, int counter){
        if(counter == 0)
           return 100;
        double max = coordinates.get(0).getX();
        
        for(int i=0; i<coordinates.size()-1; ++i){
           if (coordinates.get(i+1).getX() > coordinates.get(i).getX())
              max = coordinates.get(i+1).getX();
        }
        return max;
     } 
    public static ArrayList<Coordinates> sort(ArrayList<Coordinates> coordinates){

        if(coordinates.size() < 2){
	        return coordinates;
        } else if(coordinates.size() == 2){
        	if(coordinates.get(0).getX() > coordinates.get(1).getX()){
	            Coordinates tempCoordinate = new Coordinates(coordinates.get(0).getX(), coordinates.get(0).getY());
	            coordinates.set(0,coordinates.get(1));
	            coordinates.set(1,tempCoordinate);
	        }
	        return coordinates;
        } else{
        	for(int i=0; i<coordinates.size()-1; ++i){
          for(int j=0; j<coordinates.size()-1; ++j){
             if(coordinates.get(j).getX() > coordinates.get(j+1).getX()){
                Coordinates tempCoordinate = new Coordinates(coordinates.get(j).getX(), coordinates.get(j).getY());
                coordinates.set(j,coordinates.get(j+1));
                coordinates.set(j+1,tempCoordinate);
             }   
          }
         } 
       } 	
       return coordinates;
    }   
    public static double exponent(double value, int exp){
        if(exp == 0)
           return 1;
        return value*exponent(value, --exp);
     }
    
    public static double[] gaussian(double[][] mat, double[] v){
        int n = v.length;
        System.out.println("v length " + v.length);
        int[] l = new int[n];
        double[] s = new double[n];
        int smax = 0;
        double rmax = 0;
        double xmult = 0;
        double r;
        for(int row=0;row<n;++row){
           l[row] = row; 
           //System.out.println("n value: " + n);
           smax = row;
           for(int col=0;col<n;++col){
              System.out.println("gay i " + row);
              System.out.println("gay j " + col);
              System.out.println("gay smax" + smax);
              if(Math.abs(mat[row][col])>Math.abs(mat[smax][col]));
                 smax = col;
           } 
           //System.out.println("s max: " + smax);
           s[row] = smax;
        }  
        //System.out.println("row 2 col 3: " + g[2][3]);
        int j = 0;
        for(int k=0;k<n-1;++k){
           System.out.println("j value: " + j);
           rmax = 0;
           for(int i=k;i<n;++i){
              System.out.println("j value: " + j);          
              r = Math.abs(mat[l[i]][k]/s[l[i]]);
              System.out.println("r value: " + r);
              System.out.println("i value: " + i);
              if(r > rmax){
                 rmax = r;
                 j=i;//????????????????
                 System.out.println("j value: " + j);
              } 
              System.out.println("j value: " + j);  
           }
           System.out.println("k: " + k);
           System.out.println("j: " + j);
           int tmp = l[j];
           l[j] = l[k];
           l[k] = tmp;
           for(int i = k+1; i<n; ++i){
              xmult = mat[l[i]][k]/mat[l[k]][k];
              mat[l[i]][k] = xmult;
              for(int jtemp=k+1; jtemp<n;++jtemp){
            	  mat[l[i]][jtemp] = mat[l[i]][jtemp] - (xmult)*mat[l[k]][jtemp];
                 j=jtemp;
                 System.out.println("jjj: " + j);
              }
           }
        }
        System.out.println("it was all a dream");
        for(int i=0;i<mat.length;++i){
           for(int k=0;k<mat[i].length;++k){
              System.out.print(mat[i][k] + " " );
           }
           System.out.print("v: " + v[i]);
           System.out.println(" ");
        }
        ////////////
        /*for(int k=0; k<n-1; ++k){
           for(int i=0;i<n;++i){
              v[l[i]] = v[l[i]]-g[l[i]][k]*v[l[i]];
           }
        }*/
        ////////////
        
        for(int k=0; k<n-1; ++k){
           for(int i=k+1;i<n;++i){
              v[l[i]] = v[l[i]] - mat[l[i]][k]*v[l[k]];
           }
        }
        /*for(int i=0;i<n;++i){
           System.out.println("v vlaue: " + i + " is: " + v[i]);
        }*/
        /*System.out.println("test: ");
        for(int i=0; i<n; ++i){
           for(int j=0; j<n; ++j){
              System.out.print(g[i][j] + " ");
           }
           System.out.println(v[i]);
        } */
        double[] x = new double[n];
        double sum;
        //System.out.println("l[n-1]: " + l[n-1]);
        //System.out.println("g[n-1]: " + g[l[n-1]][n-1]);
        x[n-1]=v[l[n-1]]/mat[l[n-1]][n-1];//problem
        //System.out.println("x[n-1]: " + x[n-1]);
        for(int i = n-2; i>=0; --i){
           sum = v[l[i]];
           for(int w=i+1; w<n; ++w){
              sum = sum-mat[l[i]][w]*x[w];
           }
           x[i] = sum/mat[l[i]][i];
        }
        
        return x;

    }
    
}
